module.exports = {
    category: "Monetization",
    data: {
        name: "Get SKUs List",
    },
    UI: [
        {
            element: "store",
            name: "Store As",
            storeAs: "store",
        },
    ],
    compatibility: ["Any"],
    subtitle: (values, constants) => {
        return `Store As: ${constants.variable(values.store)}`;
    },

    async run(values, interaction, client, bridge) {
        const skus = await client.rest.applications.getSKUs(client.application.id);
        bridge.store(values.store, skus);
    },
};