module.exports = {
  data: {
    name: "Get Scheduled Actions Info",
  },
  category: "Schedules",
  UI: [
    {
      element: "input",
      storeAs: "id",
      name: "Schedule ID",
    },
    "-",
    {
      element: "typedDropdown",
      storeAs: "get",
      name: "Get",
      choices: {
        associatedInfo: { name: "Associated Info", category: "Basic Info" },
        id: { name: "ID" },
        createdAt: { name: "Creation Timestamp", category: "Time & Date" },
        time: { name: "Execution Timestamp" },
      },
    },
    "-",
    {
      element: "store",
      storeAs: "store",
    }
  ],
  subtitle: (values, constants, thisAction) => {
    return `${thisAction.UI.find(e => e.element == 'typedDropdown').choices[values.get.type].name} of ID (${values.id}) - Store As: ${constants.variable(values.store)}`
  },

  run(values, message, client, bridge) {
    let schedules = bridge.data.IO.schedules.get();
    let schedule = schedules[bridge.transf(values.id)];
    let output;
    switch (values.get.type) {
      default:
        output = schedule[values.get.type];
        break
    }

    bridge.store(values.store, output);
  },
};
