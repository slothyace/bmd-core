module.exports = {
    category: "Monetization",
    data: {
        name: "Consume Entitlement",
    },
    UI: [
        {
            element: "variable",
            name: "Entitlement",
            storeAs: "entitlement",
            help: {
                title: "Entitlement Variable",
                UI: [
                    {
                        element: "text",
                        text: "Entitlement Object/ID",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "A variable that either contains an entitlement object or an entitlement ID, to be consumed.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Consuming an entitlement is only possible if the entitlement is a consumable. Consuming an entitlement will allow the user to purchase the SKU again.",
                    },
                ],
            },
        },
    ],

    subtitle: (values, constants) => {
        return `Entitlement: ${constants.variable(values.entitlement)}`;
    },

    async run(values, interaction, client, bridge) {
        const entitlement = bridge.get(values.entitlement);
        let entitlementID;
        if (typeof entitlement !== "string") entitlementID = entitlement.id;
        else entitlementID = entitlement;
        await client.rest.applications.consumeEntitlement(client.application.id, entitlementID);
    },
};