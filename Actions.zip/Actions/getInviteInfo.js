module.exports = {
  category: "Invites",
  data: {
    name: "Get Invite Info",
  },
  UI: [
    {
      element: "var",
      storeAs: "invite",
      name: "Invite"
    },
    "-",
    {
      element: "typedDropdown",
      storeAs: "get",
      name: "Get",
      choices: {
        channel: { name: "Channel", category: "Basic Info" },
        author: { name: "Author" },
        guild: { name: "Server" },

        createdAt: { name: "Created At (Timestamp)", category: "Time & Date" },
        maxAge: { name: "Max Age (Seconds)" },

        code: { name: "Code", category: "Attributes" },
        url: { name: "URL" },

        uses: { name: "Uses", category: "Usage" },
        maxUses: { name: "Max Uses" },

        isFromEvent: { name: "Is From An Event?", category: "Misc" },
      },
    },
    "-",
    {
      element: "store",
      storeAs: "store",
      name: "Store As"
    }
  ],

  subtitle: (values, constants, thisAction) => {
    const choice = thisAction.UI.find(e => e.element === 'typedDropdown').choices[values.get.type];
    const choiceName = choice ? choice.name : values.get; // Fallback for backward compatibility
    return `${choiceName} of ${constants.variable(values.invite)} - Store As: ${constants.variable(values.store)}`;
  },

  compatibility: ["Any"],
  async run(values, _message, client, bridge) {
    let invite = bridge.get(values.invite);
    let result;

    // Handle backward compatibility
    const getType = values.get.type || values.get;

    switch (getType) {
      case 'channel':
      case 'Channel': // Backward compatibility
        result = await client.rest.channels.get(invite.channelID);
        break;
      case 'guild':
      case 'Guild': // Backward compatibility
        result = invite.guild.completeGuild;
        break;
      case 'author':
      case 'Author': // Backward compatibility
        result = invite.inviter;
        break;
      case 'uses':
      case 'Uses': // Backward compatibility
        result = invite.uses;
        break;
      case 'maxAge':
      case 'Max Age (Seconds)': // Backward compatibility
        result = invite.maxAge;
        break;
      case 'maxUses':
      case 'Max Uses': // Backward compatibility
        result = invite.maxUses;
        break;
      case 'isFromEvent':
      case 'Is From An Event?': // Backward compatibility
        result = invite.guildScheduledEvent ? true : false;
        break;
      case 'code':
      case 'Code': // Backward compatibility
        result = invite.code;
        break;
      case 'url':
      case 'URL': // Backward compatibility
        result = `https://discord.gg/${invite.code}`;
        break;
      case 'createdAt':
      case 'Created At (Timestamp)': // Backward compatibility
        result = invite.createdAt.getTime();
        break;
      default:
        throw new Error(`Unknown type: ${getType}`);
    }

    bridge.store(values.store, result);
  },
};
