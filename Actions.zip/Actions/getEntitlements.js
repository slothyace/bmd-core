module.exports = {
    category: "Monetization",
    data: {
        name: "Get Entitlements List",
    },
    UI: [
        {
            element: "inputGroup",
            nameSchemes: [ "After (Timestamp)", "Before (Timestamp)" ],
            placeholder: [ "optional", "optional" ],
            storeAs: [ "after", "before" ],
            help: {
                title: "Timestamp Filters",
                UI: [
                    {
                        element: "text",
                        text: "Timestamp Filters",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "Optional filters to get entitlements after or before a specific timestamp. You can use a variable that contains a timestamp.",
                    },
                ],
            },
        },
        "-",
        {
            element: "inputGroup",
            nameSchemes: [ "User ID", "Guild ID" ],
            placeholder: [ "optional", "optional" ],
            storeAs: [ "userID", "guildID" ],
            help: {
                title: "User & Guild ID Filters",
                UI: [
                    {
                        element: "text",
                        text: "User & Guild ID Filters",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "Optional filters to get entitlements for a specific user or guild. You can use a variable that contains a user ID or guild ID. Discord assigns the user ID or guild ID exclusively to the entitlement. User owned entitlements do not include guild ID and vice versa.",
                    },
                ],
            },
        },
        "-",
        {
            element: "toggleGroup",
            nameSchemes: [ "Exclude Deleted", "Exclude Ended" ],
            storeAs: [ "excludeDeleted", "excludeEnded" ],
            help: {
                title: "Exclude Filters",
                UI: [
                    {
                        element: "text",
                        text: "Exclude Filters",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "Optional filters to exclude deleted or ended entitlements. Deleted entitlements are those that have been removed by the user or the server. Ended entitlements are those that have expired eg. ended subscriptions.",
                    },
                ],
            },
        },
        "-",
        {
            element: "menu",
            name: "SKU IDs Filter",
            storeAs: "skuIDs",
            max: 100,
            types: { sku: ["string", "array"] },
            UItypes: {
                sku: {
                    name: "SKU ID",
                    data: { value: "" },
                    UI: [
                        {
                            element: "input",
                            name: "SKU ID",
                            placeholder: "Enter SKU ID",
                            storeAs: "value",
                        },
                    ],
                },
            },
            help: {
                title: "SKU IDs Filter",
                UI: [
                    {
                        element: "text",
                        text: "SKU IDs Filter List",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "An optional filter list of SKU IDs to filter the entitlements by. You can add multiple SKU IDs. SKU IDs can be a variable that contain either a single string (SKU ID) or an array of strings (SKU IDs).",
                    },
                ],
            },
        },
        "-",
        {
            element: "input",
            name: "Limit",
            placeholder: "optional",
            storeAs: "limit",
            type: "number",
            help: {
                title: "List Limit",
                UI: [
                    {
                        element: "text",
                        text: "List Limit",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "An optional limit to the number of entitlements that are returned.",
                    },
                ],
            },
        },
        "_",
        {
            element: "store",
            name: "Store As",
            storeAs: "store",
        }
    ],
    compatibility: ["Any"],
    subtitle: (values, constants) => {
        return `Store As: ${constants.variable(values.store)}`;
    },

    async run(values, interaction, client, bridge) {
        const params = {};
        if (values.after) params.after = values.after;
        if (values.before) params.before = values.before;
        if (values.userID) params.userID = values.userID;
        if (values.guildID) params.guildID = values.guildID;
        params.excludeDeleted = Boolean(values.excludeDeleted);
        params.excludeEnded = Boolean(values.excludeEnded);
        if (Array.isArray(values.skuIDs)) {
            const skuList = values.skuIDs.flatMap(item => {
                if (typeof item === 'string') return item;
                else if (Array.isArray(item)) return item.filter(subItem => typeof subItem === 'string');
                else if (typeof item === 'object' && item !== null && typeof item.value === 'string') return item.value;
                return [];
            }).filter(v => typeof v === 'string' && v.trim().length > 0);
            if (skuList.length > 0) {
            params.skuIDs = skuList;
            }
        }
        const lim = Number(values.limit);
        if (!isNaN(lim) && lim > 0) params.limit = lim;

        const entitlements = await client.rest.applications.getEntitlements(
            client.application.id,
            params
        );

        bridge.store(values.store, entitlements);
    },
};