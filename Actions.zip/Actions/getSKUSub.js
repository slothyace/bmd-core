module.exports = {
    category: "Monetization",
    data: {
        name: "Get Subscription",
    },
    UI: [
        {
            element: "inputGroup",
            nameSchemes: [ "SKU ID", "Subscription ID" ],
            storeAs: [ "skuID", "subscriptionID" ],
            help: {
                title: "Get Subscription",
                UI: [
                    {
                        element: "text",
                        text: "Get Get Subscription.",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "Get a subscription of a SKU by its ID and the SKU ID. Both IDs are required.",
                    },
                ],
            },
        },
        "-",
        {
            element: "store",
            name: "Store As",
            storeAs: "store",
        },
    ],
    compatibility: [ "Any" ],
    subtitle: (values, constants) => {
        return `SKU ID: ${constants.variable(values.skuID)} - Subscription ID: ${constants.variable(values.subscriptionID)} - Store As: ${constants.variable(values.store)}`;
    },

    async run(values, interaction, client, bridge) {
        bridge.store(values.store, await client.rest.applications.getSKUSubscription(values.skuID, values.subscriptionID));
    },
};