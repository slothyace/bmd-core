const { Message } = require('oceanic.js')

module.exports = {
  category: "Messages",
  data: {
    name: "Get Message Info"
  },

  UI: [
    {
      element: "message",
      name: "Message",
      storeAs: "message",
    },
    "-",
    {
      element: "typedDropdown",
      storeAs: "get",
      name: "Get",
      choices: {
        content: { name: "Content", category: "Basic Info" },
        author: { name: "Author" },
        channel: { name: "Channel" },
        jumpLink: { name: "URL" },
        id: { name: "ID" },
        server: { name: "Server" },

        createdAt: { name: "Creation Date", category: "Date & Time" },
        nonce: { name: "Nonce" },

        attachments: { name: "Attachments", category: "Lists" },
        reactions: { name: "Reactions" },
        embeds: { name: "Embeds" },
        mentionedMembersAndUsers: { name: "Mentioned Members & Users" },
        mentionedMembers: { name: "Mentioned Members" },
        mentionedUsers: { name: "Mentioned Users" },
        mentionedRoles: { name: "Mentioned Roles" },
        mentionedChannels: { name: "Mentioned Channels" },

        referencedMessage: { name: "Replied Message", category: "Attributes" },
        poll: { name: "Poll" },
        type: { name: "Type" },
        interaction: { name: "Interaction" },

        isDM: { name: "Is DM?", category: "Misc" },
        isWebhook: { name: "Is Webhook Message?" },
        isCrossposted: { name: "Is Crossposted?" },
        forwards: { name: "Forwarded Messages" },
        pinned: { name: "Is Pinned?" },
      }
    },
    "-",
    {
      element: "store",
      storeAs: "store"
    }
  ],

  compatibility: ["Any"],

  subtitle: (values, constants, thisAction) => {
    return `${thisAction.UI.find(e => e.element == 'typedDropdown').choices[values.get.type].name} of ${constants.message(values.message)} - Store As: ${constants.variable(values.store)}`
  },


  async run(values, message, client, bridge) {
    /**
     * @type {Message}
     */
    let msg = await bridge.getMessage(values.message)

    let result;
    switch (values.get.type) {
      case "createdAt":
        var cat = msg.createdAt.getTime();
        result = cat;
        break;
      case "reactions":
        let endList = [];
        let gotten = {};
        let reactions = msg.reactions;
        for (let reaction in reactions) {
          let endCount = reactions[reaction].count;
          while (endCount != 0) {
            let emoji = reactions[reaction].emoji;
            let reactionList = await msg.getReactions(`${emoji.name}${emoji.id ? ":" : ""}${emoji.id || ""}`, { limit: Infinity })
            if (!gotten[reaction]) {
              gotten[reaction] = 0;
            }
            endList.push({
              emoji: reaction.includes(":") ? reaction.split(':')[0] : reaction,
              emojiID: reaction.includes(":") ? reaction.split(':')[1] : '',
              author: reactionList[gotten[reaction]],
              message: msg
            })
            gotten[reaction] = Number(gotten[reaction]) + 1
            endCount--
          }
        }
        result = endList;
        break;
      case "isDM":
        result = msg.inDirectMessageChannel()
        break
      case "isWebhook":
        result = msg.webhookID ? true : false;
        break
      case "attachments":
        result = msg.attachments.toArray();
        break
      case "forwards":
        result = msg.messageSnapshots.filter(m => m.message);
        break
      case "mentionedMembers":
        result = msg.mentions.members;
        break
      case "mentionedUsers":
        resukt = msg.mentions.users;
      case "mentionedRoles":
        let roleMentions = msg.mentions.roles;
        result = await Promise.all(roleMentions.map(role => bridge.getRole({ type: 'id', value: role })));
        break;
      case "mentionedMembersAndUsers":
        result = msg.mentions.members.concat(msg.mentions.users);
        break
      case "mentionedChannels":
        let channelMentions = msg.mentions.channels;
        result = await Promise.all(channelMentions.map(channel => bridge.getChannel({ type: 'id', value: channel })));
        break;
      case "channel":
        let channel = await bridge.getChannel({ type: "id", value: msg.channelID });
        result = channel;
        break
      default:
        result = msg[values.get.type];
        break
    }

    bridge.store(values.store, result)
  },
};
