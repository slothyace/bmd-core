module.exports = {
    category: "Monetization",
    data: {
        name: "Get Entitlement Info",
    },
    UI: [
        {
            element: "variable",
            name: "Entitlement",
            storeAs: "entitlement",
            help: {
                title: "Entitlement Variable",
                UI: [
                    {
                        element: "text",
                        text: "Entitlement Variable",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "The entitlement object or ID to get the info from.",
                    },
                ],
            },
        },
        "-",
        {
            element: "typedDropdown",
            name: "Get",
            storeAs: "get",
            choices: {
                id: { name: "ID", category: "Entitlement Info" },
                type: { name: "Type" },
                userID: { name: "User ID" },
                guildID: { name: "Guild ID" },
                subscriptionID: { name: "Subscription ID" },
                consumed: { name: "Consumed" },
                deleted: { name: "Deleted" },
                giftCodeFlags: { name: "Gift Code Flags" },
                promotionID: { name: "Promotion ID" },

                createdAt: { name: "Created At", category: "Time & Date" },
                startsAt: { name: "Starts At" },
                endsAt: { name: "Ends At" },
                
                toJSON: { name: "Entitlment To JSON", category: "Misc"},
                toString: { name: "Entitlement To JSON (String)" },
            },
            help: {
                title: "Entitlement Info",
                UI: [
                    {
                        element: "text",
                        text: "Entitlement Info",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "The info to get from the entitlement.",
                    },
                    "-",
                    {
                        element: "text",
                        text: "ID: The ID of the entitlement.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Type: The numeric type of the entitlement. Visit the Discord Developer Portal (documentation) for more information.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "User ID: The ID of the user who owns the entitlement (if user owned).",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Guild ID: The ID of the guild that owns the entitlement (if guild owned).",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Subscription ID: The ID of the subscription.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Consumed: Whether the entitlement has been consumed.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Deleted: Whether the entitlement has been deleted.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Gift Code Flags: The flags of the gift code.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Promotion ID: The ID of the promotion.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Created At: The timestamp of when the entitlement was created.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Starts At: The timestamp of when the entitlement starts.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Ends At: The timestamp of when the entitlement ends.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Entitlement To JSON: The entitlement object as a JSON object.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Entitlement To JSON (String): The entitlement object as a JSON string.",
                    },
                ],
            },
        },
        "-",
        {
            element: "store",
            name: "Store As",
            storeAs: "store",
        },
    ],
    compatibility: ["Any"],
    subtitle: (values, constants, thisAction) => {
        return `${thisAction.UI.find(e => e.element == 'typedDropdown').choices[values.get.type].name} of ${constants.variable(values.entitlement)} - Store As: ${constants.variable(values.store)}`;
    },

    async run(values, message, client, bridge) {
        let entitlement = bridge.get(values.entitlement);
        if (typeof entitlement !== "object") {
            const entitlements = await client.rest.applications.getEntitlements(client.application.id);
            entitlement = entitlements.find(entitlement => entitlement.id === bridge.transf(values.id));
        }
        let output;
        switch (values.get.type) {
            case "id":
                output = entitlement.id;
                break;
            case "type":
                output = entitlement.type;
                break;
            case "userID":
                output = entitlement.userID;
                break;
            case "guildID":
                output = entitlement.guildId;
                break;
            case "subscriptionID":
                output = entitlement.subscriptionId;
                break;
            case "consumed":
                output = entitlement.consumed;
                break;
            case "deleted":
                output = entitlement.deleted;
                break;
            case "giftCodeFlags":
                output = entitlement.giftCodeFlags;
                break;
            case "promotionID":
                output = entitlement.promotionID;
                break;
            case "createdAt":
                output = entitlement.createdAt();
                break;
            case "startsAt":
                output = entitlement.startsAt;
                break;
            case "endsAt":
                output = entitlement.endsAt;
                break;
            case "toJSON":
                output = entitlement.toJSON();
                break;
            case "toString":
                output = JSON.stringify(entitlement.toJSON(), null, 2);
        }
        bridge.store(values.store, output);
    },
};