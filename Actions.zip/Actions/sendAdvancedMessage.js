const { ComponentTypes, ButtonStyles, ChannelTypes, InteractionTypes } = require("oceanic.js")

function isPersistent(component) {
  if (component.data) component = component.data;
  if (component.persistency?.type == "persistent") return true;
  return false;
}

let normalComponentTypes = {
  button_row: "Buttons",
  select_menu: "Select Menu",
  mentionable_select_menu: "Mentionable Select Menu",
  role_select_menu: "Role Select Menu",
  channel_select_menu: "Channel Select Menu",
  member_select_menu: "Member Select Menu",
  section_button: "Section With Button",
  section_thumbnail: "Section With Thumbnail",
  text_display: "Text Display",
  media_gallery: "Media Gallery",
  separator: "Separator",
  file: "File",
}

let boilerplate = {
  validity: {
    element: "menu",
    max: 1,
    required: true,
    bound: true,
    types: {
      validity: "Validity"
    },
    UItypes: {
      validity: {
        data: {},
        inheritData: true,
        name: "Validity",
        height: 246,
        UI: [
          {
            element: "typedDropdown",
            name: "Persistency",
            storeAs: "persistency",
            help: {
              title: "Persistency",
              UI: [
                {
                  element: "text",
                  header: true,
                  text: "Temporary"
                },
                {
                  element: "text",
                  text: `
                  This component will work for a set amount of time. It will be able to access the rest of your command like normal.<br>
                  In case you turn off the bot before the component reaches its end-of-life, it will not work anymore.
                  `
                },
                "-",
                {
                  element: "text",
                  header: true,
                  text: "Persistent"
                },
                {
                  element: "text",
                  text: `
                  This component will work forever and will remain usable across restarts.<br>
                  There are caveats; You will not be able to access temporary variables created outside of this component. To counter this, you can use Message Data.
                  `
                },
                "-",
                {
                  element: "text",
                  header: true,
                  text: "One Time"
                },
                {
                  element: "text",
                  text: `
                  Once anybody interacts with this, it stops being usable for everyone.<br>
                  This works just like a temporary component but isn't restrained by time.
                  `
                },
                "-",
                {
                  element: "text",
                  header: true,
                  text: "One Time Per User"
                },
                {
                  element: "text",
                  text: `
                  Once an user interacts with this, it stops being usable for that specific user.<br>
                  This works just like a temporary component but isn't restrained by time.
                  `
                },
              ]
            },
            choices: {
              temporary: { name: "Temporary (Seconds)", field: true, category: "Uninfluenced" },
              persistent: { name: "Persistent" },
              once: { name: "One Time", category: "Influenced" },
              once_per_user: { name: "One Time Per User" },
            }
          },
          "-",
          {
            element: "toggle",
            storeAs: "disabled",
            name: "Disabled"
          },
          "-",
          {
            element: "typedDropdown",
            name: "Custom ID <span style='opacity: 0.5;'>Don't mess with this unless you know what you're doing.</span>",
            storeAs: "customID",
            choices: {
              auto: { name: "Automatically Generated" },
              custom: { name: "Custom", field: true }
            }
          }
        ],
      }
    }
  },

  storage: {
    element: "menu",
    max: 1,
    required: true,
    storeAs: "storage",
    types: {
      storage: "Storage"
    },
    UItypes: {
      storage: {
        name: "Interaction, Selection & User Storage",
        inheritData: true,
        autoHeight: true,
        pullVariables: true,
        UI: [
          {
            element: "storage",
            name: "Store Interaction As",
            storeAs: "storeInteractionAs"
          },
          "_",
          {
            element: "storage",
            name: "Store User As",
            storeAs: "storeUserAs",
          },
        ]
      }
    }
  },

  storage_select: {
    element: "menu",
    max: 1,
    required: true,
    storeAs: "storage",
    types: {
      storage: "Storage"
    },
    UItypes: {
      storage: {
        name: "Interaction, Selection & User Storage",
        inheritData: true,
        autoHeight: true,
        pullVariables: true,
        UI: [
          {
            element: "storage",
            name: "Store Interaction As",
            storeAs: "storeInteractionAs"
          },
          "_",
          {
            element: "storage",
            name: "Store User As",
            storeAs: "storeUserAs",
          },
          "_",
          {
            element: "storage",
            name: "Store Selection List As",
            storeAs: "storeSelectionAs"
          },
        ]
      }
    }
  },

  styling: (additionalOptions) => {
    return {
      element: "menu",
      max: 1,
      required: true,
      name: "Styling",
      types: {
        styling: "Styling"
      },
      storeAs: "styling",
      UItypes: {
        styling: {
          name: "Styling",
          height: additionalOptions.height,
          inheritData: true,
          UI: additionalOptions.UI
        }
      }
    }
  },

  typed_select: (additionalOptions) => {
    return {
      name: `${additionalOptions.type} Select Menu`,
      data: { min: "1", max: "1", placeholder: "", persistency: { type: "temporary", value: "60" } },
      UI: [
        boilerplate.storage_select,
        "_",
        {
          element: "actions",
          name: "On Submit, Run",
          storeAs: "actions",
          bound: true,
        },
        boilerplate.validity,
        "-",
        boilerplate.styling({
          height: additionalOptions.additionalStyling?.length ? undefined : 184,
          UI: [
            {
              element: "input",
              storeAs: "placeholder",
              name: "Placeholder",
              placeholder: "Optional"
            },
            "-",
            {
              element: "inputGroup",
              nameSchemes: ["Min Selections", "Max Selections"],
              storeAs: ["min", "max"]
            },
            ...additionalOptions.additionalStyling || []
          ]
        })
      ],
    }
  }
}

let componentUIs = {
  button_row: {
    name: "Buttons",
    data: { components: [] },
    UI: [
      {
        element: "menu",
        storeAs: "components",
        name: "Buttons",
        max: 5,
        types: {
          button: "Button"
        },
        UItypes: {
          button: {
            name: "Button",
            data: { label: "Button", style: { type: "PRIMARY", value: "" }, url: "", emojiName: "", emojiID: "", persistency: { type: "temporary", value: "60" } },
            UI: [
              boilerplate.storage,
              "-",
              {
                element: "input",
                storeAs: "label",
                name: "Label"
              },
              "_",
              boilerplate.styling({
                height: 282,
                UI: [
                  {
                    element: "typedDropdown",
                    name: "Style",
                    storeAs: "style",
                    choices: {
                      PRIMARY: { name: "Primary (Blurple)" },
                      SECONDARY: { name: "Secondary (Gray)" },
                      SUCCESS: { name: "Success (Green)" },
                      DANGER: { name: "Danger (Red)" },
                      LINK: { name: "Link (Gray)" }
                    }
                  },
                  {
                    element: "input",
                    storeAs: "url",
                    name: "URL",
                    placeholder: "Optional - Only for Link Style",
                  },
                  "_",
                  {
                    element: "toggle",
                    storeAs: "disabled",
                    name: "Disabled"
                  },
                  "-",
                  {
                    element: "inputGroup",
                    nameSchemes: ["Emoji Name", "Emoji ID"],
                    storeAs: ["emojiName", "emojiID"],
                    placeholder: ["Optional", "Required for custom emojis"]
                  },
                ]
              }),
              "-",
              {
                element: "actions",
                name: "On Press, Run",
                storeAs: "actions",
                bound: true,
              },
              boilerplate.validity
            ]
          }
        },
      },
    ]
  },

  select_menu: {
    name: "Select Menu",
    data: { min: "1", max: "1", placeholder: "", options: [], persistency: { type: "temporary", value: "60" } },
    UI: [
      boilerplate.storage_select,
      "_",
      {
        element: "menu",
        storeAs: "options",
        name: "Options",
        max: 25,
        types: {
          option: "Option"
        },
        UItypes: {
          option: {
            name: "Option",
            data: { label: "Option", value: "", description: "" },
            height: 606,
            UI: [
              {
                element: "input",
                storeAs: "label",
                name: "Label"
              },
              "_",
              {
                element: "input",
                storeAs: "description",
                name: "Description",
                placeholder: "Optional"
              },
              "_",
              {
                element: "input",
                storeAs: "value",
                name: "Value"
              },
              "-",
              {
                element: "inputGroup",
                nameSchemes: ["Emoji Name", "Emoji ID"],
                storeAs: ["emojiName", "emojiID"],
                placeholder: ["Optional", "Required for custom emojis"]
              },
              "-",
              {
                element: "toggle",
                storeAs: "default",
                name: "Default"
              },
              "_",
              {
                element: "actions",
                name: "If Selected, Run",
                storeAs: "actions",
              },
            ]
          }
        }
      },
      "-",
      {
        element: "actions",
        name: "On Submit, Run",
        storeAs: "actions",
        bound: true
      },
      boilerplate.validity,
      "-",
      boilerplate.styling({
        height: 180,
        UI: [
          {
            element: "toggle",
            storeAs: "disabled",
            name: "Disabled"
          },
          "-",
          {
            element: "input",
            storeAs: "placeholder",
            name: "Placeholder",
            placeholder: "Optional"
          }
        ]
      })
    ]
  },

  mentionable_select_menu: boilerplate.typed_select({ type: "Mentionable" }),
  role_select_menu: boilerplate.typed_select({ type: "Role" }),
  channel_select_menu: boilerplate.typed_select({
    type: "Channel", data: { includeTextChannels: true }, additionalStyling: [
      "-",
      {
        element: "toggle",
        storeAs: "includeTextChannels",
        name: "Include Text Channels",
      },
      "_",
      {
        element: "toggle",
        storeAs: "includeVoiceChannels",
        name: "Include Voice Channels",
      },
      "_",
      {
        element: "toggle",
        storeAs: "includeCategories",
        name: "Include Categories",
      },
      "_",
      {
        element: "toggle",
        storeAs: "includeAnnouncementChannels",
        name: "Include Announcement Channels",
      },
      "_",
      {
        element: "toggle",
        storeAs: "includeAnnouncementThreadChannels",
        name: "Include Announcement Thread Channels",
      },
      "_",
      {
        element: "toggle",
        storeAs: "includePublicThreadChannels",
        name: "Include Public Thread Channels",
      },
      "_",
      {
        element: "toggle",
        storeAs: "includePrivateThreadChannels",
        name: "Include Private Thread Channels",
      },
      "_",
      {
        element: "toggle",
        storeAs: "includeStageChannels",
        name: "Include Stage Channels",
      },
      "_",
      {
        element: "toggle",
        storeAs: "includeForumChannels",
        name: "Include Forum Channels",
      }
    ]
  }),
  member_select_menu: boilerplate.typed_select({ type: "Member" }),

  text_display: {
    name: "Text Display",
    data: { text: "" },
    UI: [
      {
        element: "largeInput",
        storeAs: "text",
        name: "Text"
      },
    ]
  },

  media_gallery: {
    name: "Media Gallery",
    data: { items: [] },
    height: 268,
    UI: [
      {
        element: "menu",
        storeAs: "items",
        name: "Items",
        types: {
          image: "Image",
        },
        UItypes: {
          image: {
            name: "Image",
            height: 242,
            data: { image: "" },
            UI: [
              {
                element: "input",
                storeAs: "url",
                name: "Image URL"
              },
              "-",
              {
                element: "input",
                storeAs: "description",
                name: "Description",
                placeholder: "Optional"
              },
              "-",
              {
                element: "toggle",
                storeAs: "spoiler",
                name: "Spoiler"
              }
            ]
          }
        },
        max: 10
      }
    ]
  },

  separator: {
    name: "Separator",
    height: 180,
    data: { divider: true, spacing: { type: "large", value: "" } },
    UI: [
      {
        element: "toggle",
        storeAs: "divider",
        name: "Divider"
      },
      "-",
      {
        element: "typedDropdown",
        storeAs: "spacing",
        name: "Spacing",
        choices: {
          small: { name: "Small" },
          large: { name: "Large" }
        }
      }
    ]
  },

  file: {
    name: "File",
    data: { file: "" },
    UI: [
      {
        element: "input",
        storeAs: "file",
        name: "File",
      },
      "-",
      {
        element: "toggle",
        storeAs: "spoiler",
        name: "Spoiler"
      }
    ]
  },


  section_thumbnail: {
    name: "Section With Thumbnail",
    data: {},
    UI: [
      {
        element: "menu",
        storeAs: "components",
        name: "Components",
        types: {
          text_display: "Text",
        },
        UItypes: {
          text_display: {
            name: "Text",
            data: { text: "" },
            UI: [
              {
                element: "largeInput",
                storeAs: "text",
                name: "Text"
              }
            ]
          }
        },
        max: 10,
      },
    ]
  },
}

componentUIs.section_button = {
  name: "Section With Button",
  data: { accessory: [{ type: "button", data: { label: "Section Button", persistency: { type: "temporary", value: "60" }, style: { type: "PRIMARY", value: "" }, disabled: false } }] },
  UI: [
    {
      element: "menu",
      storeAs: "components",
      name: "Components",
      types: {
        text_display: "Text",
      },
      UItypes: {
        text_display: {
          name: "Text",
          data: { text: "" },
          UI: [
            {
              element: "largeInput",
              storeAs: "text",
              name: "Text"
            }
          ]
        }
      },
      max: 10,
    },
    "-",
    {
      element: "menu",
      storeAs: "accessory",
      max: 1,
      required: true,
      types: {
        button: "Button"
      },
      UItypes: {
        button: componentUIs.button_row.UI[0].UItypes.button
      }
    }
  ]
},

  module.exports = {
    data: {
      name: "Send Advanced Message",
    },
    category: "Messages",
    aliases: ["Create Message", "DM User", "Send Message To Channel", "Interaction Reply"],
    UI: [
      {
        element: "menu",
        storeAs: "components",
        name: "Components",
        types: {
          container: "Container",
          button_row: "Buttons",
          select_menu: "Select Menu",
          mentionable_select_menu: "Mentionable Select Menu",
          role_select_menu: "Role Select Menu",
          channel_select_menu: "Channel Select Menu",
          member_select_menu: "Member Select Menu",
        },
        UItypes: {
          ...componentUIs,
          container: {
            name: "Container",
            data: { components: [], spoiler: false, accent: "" },
            height: 388,
            UI: [
              {
                element: "input",
                type: "color",
                storeAs: "accent",
                name: "Accent",
                placeholder: "Optional",
              },
              "-",
              {
                element: "toggle",
                storeAs: "spoiler",
                name: "Spoiler"
              },
              "-",
              {
                element: "menu",
                storeAs: "components",
                name: "Components",
                types: normalComponentTypes,
                UItypes: componentUIs,
                max: 40
              }
            ]
          },
        },
        max: 5
      },
      "-",
      {
        element: "menu",
        name: "Attachments",
        storeAs: "attachments",
        max: 10,
        types: {
          attachment: "Attachment",
        },
        UItypes: {
          attachment: {
            height: 294,
            name: "Attachment",
            data: { name: "" },
            preview: "`Name: ${option.data.name}`",
            pullVariables: true,
            UI: [
              {
                element: "image",
                storeAs: "image",
                name: "File"
              },
              "-",
              {
                element: "input",
                name: "Attachment Name",
                storeAs: "name"
              },
              "_",
              {
                element: "toggle",
                storeAs: "spoiler",
                name: "Mark As Spoiler?"
              },
              "-",
              {
                element: "store",
                storeAs: "store",
                name: "Store Format As"
              }
            ]
          }
        }
      },
      "-",
      {
        element: "channel",
        storeAs: "channel",
      },
    ],

    subtitle: (values, constants, thisAction) => {
      return `${constants.channel(values.channel)}`
    },

    startup: (bridge, client) => {
      bridge.createGlobal({
        name: "persistent",
        class: "handlers",
        value: {}
      });
      bridge.createGlobal({
        name: "temporary",
        class: "handlers",
        value: {}
      });


      client.on('interactionCreate', async (interaction) => {
        if (interaction.type != InteractionTypes.MESSAGE_COMPONENT) return;

        let tempVars = {};
        let { serverVars } = bridge.data;
        let { globalVars } = bridge.data;

        function store(blob, value) {
          if (blob.type == "temporary") {
            tempVars[blob.value] = value;
          } else if (blob.type == "server") {
            serverVars[interaction.guildID][blob.value] = value;
          } else if (blob.type == "global") {
            globalVars[blob.value] = value;
          }
        }

        let handlers = bridge.getGlobal({ name: "persistent", class: "handlers" });
        let componentID = interaction.data.customID;
        let handler = handlers[componentID];
        if (handler) {
          if (handler.storage.message) {
            store(handler.storage.message, interaction.message);
          }
          if (handler.storage.interaction) {
            store(handler.storage.interaction, interaction);
          }
          if (handler.storage.user) {
            store(handler.storage.user, interaction.member.user);
          }
          if (handler.storage.selection) {
            let selection = [];
            if (interaction.data.componentType == ComponentTypes.STRING_SELECT) {
              selection = interaction.data.values.raw.map(v => handler.options[v].data.pushValue);
              for (let value of interaction.data.values.raw) {
                let option = handler.options[value].data;
                if (option.actions?.length) {
                  bridge.runActionArray(option.actions, interaction, tempVars, {
                    temporaries: {
                      class: "interactionStuff",
                      name: "current",
                      value: interaction
                    },
                    guild: interaction.guild,
                  });
                }
              }
            } else {
              let values = interaction.data.resolved;
              for (let channel of values.channels) {
                let endChannel = client.getChannel(channel[0]) || await client.rest.channels.get(channel[0]);
                selection.push(endChannel);
              }
              for (let role of values.roles) {
                let endRole = interaction.guild.roles.get(role[0]);
                selection.push(endRole);
              }
              for (let user of values.users) {
                let endUser = client.users.get(user[0]) || await client.rest.users.get(user[0]);
                selection.push(endUser);
              }
            }
            store(handler.storage.selection, selection);
          }

          bridge.runActionArray(handler.actions, interaction, tempVars, {
            temporaries: {
              class: "interactionStuff",
              name: "current",
              value: interaction
            },
            guild: interaction.guild,
          });
        }

        handlers = bridge.getGlobal({ name: "temporary", class: "handlers" });
        componentID = interaction.message.id;
        handler = handlers[componentID];
        if (!handler) return;
        let component = handler.components[interaction.data.customID];
        if (!component) return;
        if (!component.actions?.length) return;
        let componentBridge = handler.bridge;
        componentBridge.createTemporary({
          class: "interactionStuff",
          name: "current",
          value: interaction
        });
        componentBridge.store(component.storage.user, interaction.user);
        componentBridge.store(component.storage.interaction, interaction);
        if (component.storage.selection) {
          let valueList = [];
          if (interaction.data.componentType == ComponentTypes.STRING_SELECT) {
            for (let value of interaction.data.values.raw) {
              valueList.push(component.options[value].pushValue)
              componentBridge.runner(component.options[value].actions)
            }
          } else {
            let values = interaction.data.values.resolved;
            for (let channel of values.channels) {
              let resolvedChannel = await componentBridge.getChannel({ type: "id", value: channel[0] });
              valueList.push(resolvedChannel)
            }
            for (let role of values.roles) {
              let resolvedRole = await componentBridge.getRole({ type: "id", value: role[0] });
              valueList.push(resolvedRole)
            }
            for (let user of values.users) {
              let resolvedUser = await componentBridge.getUser({ type: "id", value: user[0] });
              valueList.push(resolvedUser)
            }
          }

          componentBridge.store(component.storage.selection, valueList)
        }
        componentBridge.runner(component.actions)
      })
    },

    init: (values, bridge) => {
      let handlers = bridge.getGlobal({ name: "persistent", class: "handlers" });
      if (!handlers) {
        handlers = {};
      }
      let componentIndexID = 0;

      function getComponentID(component) {
        if (component.data?.customID?.type == "custom") {
          return component.data.customID.value
        } else {
          componentIndexID++;
          return `${bridge.data.id}-${componentIndexID}`
        }
      }

      function getComponents(components) {
        for (let index in components) {
          if (components[index].type == "container") {
            getComponents(components[index].data.components)
          } else if (components[index].type == "button_row" || components[index].type == "button_row") {
            for (let buttonIndex in components[index].data.components) {
              let button = components[index].data.components[buttonIndex];
              let buttonID = getComponentID(button);
              if (isPersistent(button)) {
                handlers[buttonID] = {
                  type: "button",
                  actions: button.data.actions,
                  storage: {
                    interaction: button.data.storeInteractionAs,
                    user: button.data.storeUserAs,
                    message: values.storeAs
                  }
                }
              }
            }
          } else if (components[index].type == "select_menu") {
            let selectMenu = components[index].data;
            let selectMenuID = getComponentID(selectMenu);
            if (isPersistent(selectMenu)) {
              handlers[selectMenuID] = {
                type: "select",
                actions: selectMenu.actions,
                storage: {
                  interaction: selectMenu.storeInteractionAs,
                  user: selectMenu.storeUserAs,
                  selection: selectMenu.storeSelectionAs,
                  message: values.storeAs
                },
                options: selectMenu.options
              }
              for (let optionIndex in selectMenu.options) {
                let option = selectMenu.options[optionIndex];
                handlers[selectMenuID].options[optionIndex] = option;
              }
            }
          } else if (components[index].type == "mentionable_select_menu" || components[index].type == "role_select_menu" || components[index].type == "channel_select_menu" || components[index].type == "member_select_menu") {
            let selectMenu = components[index].data;
            let selectMenuID = getComponentID(selectMenu);
            if (isPersistent(selectMenu)) {
              handlers[selectMenuID] = {
                type: components[index].type,
                actions: selectMenu.actions,
                storage: {
                  interaction: selectMenu.storeInteractionAs,
                  user: selectMenu.storeUserAs,
                  selection: selectMenu.storeSelectionAs,
                  message: values.storeAs
                }
              }
            }
          }
        }
      }
      getComponents(values.components);
      bridge.createGlobal({ name: "persistent", class: "handlers", value: handlers });
    },

    run: async (values, command, client, bridge) => {
      if (values.attachments) {
        for (let attachment of values.attachments) {
          if (attachment.data.store) {
            bridge.store(attachment.data.store, `attachment://${bridge.transf(attachment.data.name)}`);
          }
        }
      }

      let t = bridge.transf;
      let channel = await bridge.getChannel(values.channel);

      let componentIndexID = 0;

      let endActionRows = {};

      function generateComponentID(component) {
        if (component.data?.customID?.type == "custom") {
          return component.data.customID.value
        } else {
          componentIndexID++;
          return `${bridge.data.id}-${componentIndexID}`
        }
      }

      async function convertComponents(components) {
        let thisComponents = [];
        for (let index in components) {
          let component = components[index];
          if (component.type == "container") {
            let components = await convertComponents(component.data.components);
            thisComponents.push({
              type: 17,
              components,
              accentColor: component.data.accent ? parseInt(t(component.data.accent).replace("#", ""), 16) : null,
            })
          } else if (component.type == "text_display" || component.type == "text") {
            thisComponents.push({
              type: 10,
              content: t(component.data.text),
            })
          } else if (component.type == "separator") {
            thisComponents.push({
              type: ComponentTypes.SEPARATOR,
              spacing: component.data.spacing.type == "small" ? 1 : 2,
              divider: component.data.divider || false,
            })
          } else if (component.type == "section_button") {
            thisComponents.push({
              type: ComponentTypes.SECTION,
              accessory: await convertComponents(component.data.accessory)[0],
              components: await convertComponents(component.data.components),
              accentColor: component.data.accent ? parseInt((t(component.data.accent) || "").replace("#", ""), 16) : null,
            })
          } else if (component.type == "button_row") {
            let buttons = await convertComponents(component.data.components);
            thisComponents.push({
              type: ComponentTypes.ACTION_ROW,
              components: buttons
            })
          } else if (component.type == "button") {
            let emoji;
            if (component.data.emojiName) {
              emoji = {
                name: t(component.data.emojiName)
              }
              if (component.data.emojiID) {
                emoji.id = component.data.emojiID;
              }
            }

            let button = {
              type: ComponentTypes.BUTTON,
              style: ButtonStyles[component.data.style?.type || "PRIMARY"],
              label: t(component.data.label),
              customID: generateComponentID(component),
              disabled: component.data.disabled || false,
              url: component.data.style.type == "LINK" ? t(component.data.url) : null,
              emoji
            }

            if (!isPersistent(component)) {
              endActionRows[button.customID] = {
                type: "button",
                actions: component.data.actions,
                storage: {
                  interaction: component.data.storeInteractionAs,
                  user: component.data.storeUserAs
                },
                duration: bridge.transf(component.data.persistency.value)
              }
            }
            thisComponents.push(button);
          } else if (component.type == "select_menu") {
            let selectMenu = {
              type: ComponentTypes.STRING_SELECT,
              customID: generateComponentID(component),
              placeholder: t(component.data.placeholder),
              minValues: parseInt(component.data.min) || 0,
              maxValues: parseInt(component.data.max) || 1,
              options: [],
              disabled: component.data.disabled || false
            }

            let endOptions = {};

            for (let optionIndex in component.data.options) {
              let option = component.data.options[optionIndex];
              let emoji;
              if (option?.data?.emojiName) {
                emoji = {
                  name: t(option.data.emojiName)
                }
                if (option.data.emojiID) {
                  emoji.id = option.data.emojiID;
                }
              }

              selectMenu.options.push({
                label: t(option.data.label),
                value: optionIndex,
                description: option.data.description ? t(option.data.description) : undefined,
                default: option.data.default || false,
                emoji
              });

              endOptions[optionIndex] = {
                actions: option.data.actions,
                pushValue: bridge.transf(option.data.value)
              };
            }

            if (!isPersistent(component)) {
              endActionRows[selectMenu.customID] = {
                type: "select",
                actions: component.data.actions,
                storage: {
                  interaction: component.data.storeInteractionAs,
                  user: component.data.storeUserAs,
                  selection: component.data.storeSelectionAs
                },
                options: endOptions,
                duration: bridge.transf(component.data.persistency.value)
              }
            }

            thisComponents.push({
              type: ComponentTypes.ACTION_ROW,
              components: [selectMenu]
            })
          } else if (component.type == "mentionable_select_menu" || component.type == "role_select_menu" || component.type == "channel_select_menu" || component.type == "member_select_menu") {
            let additionalStuff = {};
            if (component.type == "channel_select_menu") {
              additionalStuff.channelTypes = [];
              if (component.data.includeTextChannels) additionalStuff.channelTypes.push(ChannelTypes.GUILD_TEXT);
              if (component.data.includeVoiceChannels) additionalStuff.channelTypes.push(ChannelTypes.GUILD_VOICE);
              if (component.data.includeAnnouncementThreadChannels) additionalStuff.channelTypes.push(ChannelTypes.ANNOUNCEMENT_THREAD);
              if (component.data.includePublicThreadChannels) additionalStuff.channelTypes.push(ChannelTypes.PUBLIC_THREAD);
              if (component.data.includePrivateThreadChannels) additionalStuff.channelTypes.push(ChannelTypes.PRIVATE_THREAD);
              if (component.data.includeAnnouncementChannels) additionalStuff.channelTypes.push(ChannelTypes.GUILD_ANNOUNCEMENT);
              if (component.data.includeCategories) additionalStuff.channelTypes.push(ChannelTypes.GUILD_CATEGORY);
              if (component.data.includeStageChannels) additionalStuff.channelTypes.push(ChannelTypes.GUILD_STAGE_VOICE);
              if (component.data.includeForumChannels) additionalStuff.channelTypes.push(ChannelTypes.GUILD_FORUM);
            }
            let map = {
              mentionable_select_menu: ComponentTypes.MENTIONABLE_SELECT,
              role_select_menu: ComponentTypes.ROLE_SELECT,
              channel_select_menu: ComponentTypes.CHANNEL_SELECT,
              member_select_menu: ComponentTypes.USER_SELECT
            }
            let selectMenu = {
              type: map[component.type],
              customID: generateComponentID(component),
              placeholder: t(component.data.placeholder),
              minValues: parseInt(component.data.min) || 0,
              maxValues: parseInt(component.data.max) || 1,
              options: [],
              disabled: component.data.disabled || false,
              ...additionalStuff
            }

            if (!isPersistent(component)) {
              endActionRows[selectMenu.customID] = {
                type: component.type,
                actions: component.data.actions,
                storage: {
                  interaction: component.data.storeInteractionAs,
                  user: component.data.storeUserAs,
                  selection: component.data.storeSelectionAs
                },
                duration: bridge.transf(component.data.persistency.value)
              }
            }

            thisComponents.push({
              type: ComponentTypes.ACTION_ROW,
              components: [selectMenu]
            })
          } else if (component.type == "media_gallery") {
            thisComponents.push({
              items: component.data.items.map((item) => {
                return {
                  media: { url: bridge.transf(item.data.url) },
                  description: item.data.description ? bridge.transf(item.data.description) || undefined : undefined,
                  spoiler: item.data.spoiler
                }
              }),
              type: ComponentTypes.MEDIA_GALLERY
            });
          }

        }
        return thisComponents
      }

      let attachments = [];

      if (values.attachments && values.attachments.length > 0) {
        await Promise.all(
          values.attachments.map(async (a) => {
            const attachment = a.data;
            const buffer = await bridge.getImage(attachment.image);
            const attachmentName = bridge.transf(attachment.name);
            attachments.push({
              contents: buffer,
              name: attachment.spoiler ? `SPOILER_${attachmentName}` : attachmentName,
            });
          })
        );
      }

      let endComponents = await convertComponents(values.components);
      let message = await channel.createMessage({
        components: endComponents,
        flags: 32768,
        files: attachments,
      });

      let temporaryHandlers = bridge.getGlobal({ name: "temporary", class: "handlers" });
      temporaryHandlers[message.id] = {
        components: endActionRows,
        bridge
      };
      for (let r in endActionRows) {
        let row = endActionRows[r];
        setTimeout(() => {
          temporaryHandlers[message.id].components[r].actions = [];
        }, row.duration * 1000);
      }
    }
  }