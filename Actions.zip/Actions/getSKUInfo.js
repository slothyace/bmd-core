module.exports = {
    category: "Monetization",
    data: {
        name: "Get SKU Info",
    },
    UI: [
        {
            element: "variable",
            name: "SKU",
            storeAs: "sku",
            help: {
                title: "SKU Variable",
                UI: [
                    {
                        element: "text",
                        text: "SKU Variable",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "The SKU object or ID to get the info from.",
                    },
                ],
            },
        },
        "-",
        {
            element: "typedDropdown",
            name: "Get",
            storeAs: "get",
            choices: {
                id: { name: "ID", category: "SKU Info" },
                name: { name: "Name" },
                type: { name: "Type" },
                accessType: { name: "Access Type" },
                features: { name: "Features" },
                flags: { name: "Flags" },
                manifestLabels: { name: "Manifest Labels" },
                slug: { name: "Slug" },

                createdAt: { name: "Created At", category: "Time & Date" },
                releaseDate: { name: "Release Date" },

                entitlements: { name: "Entitlements", category: "Entitlements" },

                toJSON: { name: "SKU To JSON", category: "Misc" },
                toString: { name: "SKU To JSON (String)" },
            },
            help: {
                title: "SKU Info",
                UI: [
                    {
                        element: "text",
                        text: "SKU Info",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "The info to get from the SKU.",
                    },
                    "-",
                    {
                        element: "text",
                        text: "ID: The ID of the SKU.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Name: The name of the SKU.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Type: The numeric type of the SKU. Visit the Discord Developer Portal (documentation) for more information.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Access Type: The numeric access type of the SKU.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Features: The list (array) of features from the SKU.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Flags: The flags from the SKU (numeric).",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Manifest Labels: The manifest labels from the SKU.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Slug: The slug of the SKU.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Created At: The timestamp of when the SKU was created.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Release Date: The release date of the SKU.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Entitlements: The list (array) of all entitlements of the SKU.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "SKU To JSON: The SKU object as a JSON object.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "SKU To JSON (String): The SKU object as a JSON string.",
                    },
                ],
            },
        },
        "-",
        {
            element: "store",
            name: "Store As",
            storeAs: "store",
        },
    ],
    compatibility: ["Any"],
    subtitle: (values, constants, thisAction) => {
        return `${thisAction.UI.find(e => e.element == 'typedDropdown').choices[values.get.type].name} of ${constants.variable(values.sku)} - Store As: ${constants.variable(values.store)}`;
    },

    async run(values, message, client, bridge) {
        let sku = bridge.get(values.sku);
        if (typeof sku !== "object") {
            const skus = await client.rest.applications.getSKUs(client.application.id);
            sku = skus.find(sku => sku.id === bridge.transf(values.id));
        }
        let output;
        switch (values.get.type) {
            case "id":
                output = sku.id;
                break;
            case "name":
                output = sku.name;
                break;
            case "type":
                output = sku.type;
                break;
            case "accessType":
                output = sku.accessType;
                break;
            case "features":
                output = sku.features;
                break;
            case "flags":
                output = sku.flags;
                break;
            case "manifestLabels":
                output = sku.manifestLabels;
                break;
            case "slug":
                output = sku.slug;
                break;
            case "createdAt":
                output = sku.createdAt();
                break;
            case "releaseDate":
                output = sku.releaseDate;
                break;
            case "entitlements":
                output = await sku.getEntitlements();
                break;
            case "toJSON":
                output = sku.toJSON();
                break;
            case "toString":
                output = JSON.stringify(sku.toJSON(), null, 2);
        }
        bridge.store(values.store, output);
    },
};