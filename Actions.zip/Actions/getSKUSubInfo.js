module.exports = {
    category: "Monetization",
    data: {
        name: "Get Subscription Info",
    },
    UI: [
        {
            element: "variable",
            name: "Subscription",
            storeAs: "subscription",
            help: {
                title: "Subscription Variable",
                UI: [
                    {
                        element: "text",
                        text: "Subscription Variable",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "The subscription object or ID to get the info from.",
                    },
                ],
            },
        },
        "-",
        {
            element: "typedDropdown",
            name: "Get",
            storeAs: "get",
            choices: {
                id: { name: "ID", category: "Subscription Info" },
                userID: { name: "User ID" },
                status: { name: "Status" },
                country: { name: "Country" },

                skuIDs: { name: "SKU IDs", category: "SKUs & Entitlements" },
                renewalSKUIDs: { name: "Renewal SKU IDs" },
                entitlementIDs: { name: "Entitlement IDs" },

                createdAt: { name: "Created At", category: "Time & Date" },
                cancledAt: { name: "Canceled At" },
                currentPeriodStart: { name: "Current Period Start" },
                currentPeriodEnd: { name: "Current Period End" },

                toJSON: { name: "Subscription To JSON", category: "Misc" },
                toString: { name: "Subscription To JSON (String)" },
            },
            help: {
                title: "Subscription Info",
                UI: [
                    {
                        element: "text",
                        text: "Subscription Info",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "The info to get from the subscription.",
                    },
                    "-",
                    {
                        element: "text",
                        text: "ID: The ID of the subscription.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "User ID: The ID of the user who owns the subscription.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Status: The numeric status of the subscription. ACTIVE: 0, ENDING: 1, INACTIVE: 2.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Country: The ISO3166-1 alpha-2 country code of the payment source used to purchase the subscription.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "SKU IDs: The ID list (array) of the SKUs associated with the subscription.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Renewal SKU IDs: The ID list (array) of SKUs that this user will be subscribed to at renewal.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Entitlement IDs: The ID list (array) of entitlements associated with the subscription.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Created At: The timestamp of when the subscription was created.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Canceled At: The timestamp of when the subscription was canceled.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Current Period Start: The timestamp of when the current period started.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Current Period End: The timestamp of when the current period ends.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Subscription To JSON: The subscription object as a JSON object.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "Subscription To JSON (String): The subscription object as a JSON string.",
                    },
                ],
            },
        },
        "-",
        {
            element: "store",
            name: "Store As",
            storeAs: "store",
        },
    ],
    compatibility: ["Any"],
    subtitle: (values, constants, thisAction) => {
        return `${thisAction.UI.find(e => e.element == 'typedDropdown').choices[values.get.type].name} of ${constants.variable(values.subscription)} - Store As: ${constants.variable(values.store)}`;
    },

    async run(values, message, client, bridge) {
        let subscription = bridge.get(values.subscription)
        if (typeof subscription !== "object") {
            const subscriptions = await client.rest.applications.getSKUSubscriptions(client.application.id);
            subscription = subscriptions.find(subscription => subscription.id === bridge.transf(values.id));
        }
        let output;
        switch (values.get.type) {
            case "id":
                output = subscription.id;
                break;
            case "userID":
                output = subscription.userID;
                break;
            case "status":
                output = subscription.status;
                break;
            case "country":
                output = subscription.country;
                break;
            case "skuIDs":
                output = subscription.skuIDs;
                break;
            case "renewalSKUIDs":
                output = subscription.renewalSKUIDs;
                break;
            case "entitlementIDs":
                output = subscription.entitlementIDs;
                break;
            case "createdAt":
                output = subscription.createdAt();
                break;
            case "cancledAt":
                output = subscription.canceledAt;
                break;
            case "currentPeriodStart":
                output = subscription.currentPeriodStart;
                break;
            case "currentPeriodEnd":
                output = subscription.currentPeriodEnd;
                break;
            case "toJSON":
                output = subscription.toJSON();
                break;
            case "toString":
                output = JSON.stringify(subscription.toJSON(), null, 2);
        }
        bridge.store(values.store, output);
    },
};