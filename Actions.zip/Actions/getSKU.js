module.exports = {
    category: "Monetization",
    data: {
        name: "Get SKU",
    },
    UI: [
        {
            element: "input",
            name: "SKU ID",
            storeAs: "id",
            help: {
                title: "SKU ID",
                UI: [
                    {
                        element: "text",
                        text: "SKU ID",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "The ID of the SKU to get. Can also be a variable that contains the ID.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "This will return the SKU object and stores it in the variable specified in the 'Store As' field.",
                    },
                ],
            },
        },
        "-",
        {   
            element: "store",
            name: "Store As",
            storeAs: "store",
        },
    ],
    compatibility: ["Any"],
    subtitle: (values, constants, thisAction) => {
        return `SKU ID: ${constants.variable(values.id)} - Store As: ${constants.variable(values.store)}`;
    },

    async run(values, interaction, client, bridge) {
        const skus = await client.rest.applications.getSKUs(client.application.id);
        const sku = skus.find(sku => sku.id === bridge.transf(values.id));
        bridge.store(values.store, sku);
    },
};