module.exports = {
    category: "Monetization",
    data: {
        name: "Get Subscriptions List",
    },
    UI: [
        {
            element: "inputGroup",
            nameSchemes: ["After (Timestamp)", "Before (Timestamp)"],
            placeholder: [ "optional", "optional" ],
            storeAs: ["after", "before"],
            help: {
                title: "Timestamp Filters",
                UI: [
                    {
                        element: "text",
                        text: "Timestamp Filters",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "Optional filters to get subscriptions after or before a specific timestamp. You can use a variable that contains a timestamp.",
                    },
                ],
            },
        },
        "-",
        {
            element: "input",
            name: "User ID",
            placeholder: "optional",
            storeAs: "userID",
            help: {
                title: "User ID Filter",
                UI: [
                    {
                        element: "text",
                        text: "User ID Filter",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "Optional filter to get subscriptions for a specific user. You can use a variable that contains a user ID.",
                    },
                ],
            },
        },
        "-",
        {
            elemen: "input",
            name: "Limit",
            placeholder: "optional",
            storeAs: "limit",
            type: "number",
            help: {
                title: "List Limit",
                UI: [
                    {
                        element: "text",
                        text: "List Limit",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "Optional limit for the number of subscriptions to retrieve. You can use a variable that contains a number.",
                    },
                ],
            },
        },
        "_",
        {
            element: "store",
            name: "Store As",
            storeAs: "store",
        },
    ],
    compatibility: [ "Any" ],
    subtitle: (values, constants) => {
        return `Store As: ${constants.variable(values.store)}`;
    },

    async run(values, interaction, client, bridge) {
        const params = {}
        if (values.after) params.after = values.after;
        if (values.before) params.before = values.before;
        if (values.userID) params.userID = values.userID;
        const lim = Number(values.limit);
        if (!isNaN(lim) && lim > 0) {
            params.limit = lim;
        }

        const subscriptions = await client.rest.applications.getSKUSubscriptions(
            client.application.id,
            params
        );

        bridge.store(values.store, subscriptions);
    },
};