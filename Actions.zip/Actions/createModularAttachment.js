module.exports = {
  category: "Modularity",
  data: { name: "Create Modular Attachment", inline: true },
  UI: [
    {
      element: "image",
      storeAs: "image",
      name: "File"
    },
    "-",
    {
      element: "input",
      name: "Attachment Name",
      storeAs: "name"
    },
    {
      element: "toggle",
      storeAs: "spoiler",
      name: "Mark As Spoiler?"
    },
    "-",
    {
      element: "store",
      storeAs: "storeFormat",
      optional: true,
      name: "Store Format As"
    },
    "_",
    {
      element: "store",
      storeAs: "store",
      name: "Store As"
    }
  ],

  subtitle: (data, constants) => {
    return `Store As: ${constants.variable(data.store)}`
  },

  async run(values, message, client, bridge) {
    const buffer = await bridge.getImage(values.image);
    const attachmentName = bridge.transf(values.name);
    if (values.spoiler) {
      attachmentName = `SPOILER_${attachmentName}`
    }
    bridge.store(values.storeFormat, `attachment://${bridge.transf(values.name)}`);
    bridge.store(values.store, {
      contents: buffer,
      name: attachmentName,
    });
  },
};