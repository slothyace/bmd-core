module.exports = {
    category: "Monetization",
    data: {
        name: "Get Entitlement",
    },
    UI: [
        {
            element: "input",
            name: "Entitlement ID",
            storeAs: "id",
            help: {
                title: "Entitlement ID",
                UI: [
                    {
                        element: "text",
                        text: "Entitlement ID (Variable)",
                        header: true,
                    },
                    {
                        element: "text",
                        text: "The ID of the entitlement to get. Can also be a variable that contains the ID.",
                    },
                    "_",
                    {
                        element: "text",
                        text: "This will return the entitlement object and stores it in the variable specified in the 'Store As' field.",
                    },
                ],
            },
        },
        "-",
        {   
            element: "store",
            name: "Store As",
            storeAs: "store",
        },
    ],
    compatibility: ["Any"],
    subtitle: (values, constants) => {
        return `Entitlement ID: ${values.id} - Store AS: ${constants.variable(values.store)}`;
    },
    
    async run(values, interaction, client, bridge) {
        const entitlements = await client.rest.applications.getEntitlements(client.application.id);
        const entitlement = entitlements.find(entitlement => entitlement.id === bridge.transf(values.id));
        bridge.store(values.store, entitlement);
    },
};