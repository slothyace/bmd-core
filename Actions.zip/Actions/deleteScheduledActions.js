module.exports = {
  data: {
    name: "Delete Scheduled Actions",
  },
  category: "Schedules",
  UI: [
    {
      element: "input",
      storeAs: "id",
      name: "Schedule ID",
    },
  ],
  subtitle: (values, constants, thisAction) => {
    return `ID (${values.id})`
  },

  run(values, message, client, bridge) {
    let schedules = bridge.data.IO.schedules.get();
    delete schedules[bridge.transf(values.id)];
    bridge.data.IO.schedules.write(schedules)
  },
};
