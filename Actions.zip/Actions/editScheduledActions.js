module.exports = {
  data: {
    name: "Edit Scheduled Actions",
    associatedInfo: { value: "", type: "dontChange" },
    time: { value: "", type: "dontChange" },
  },
  category: "Schedules",
  UI: [
    {
      element: "input",
      storeAs: "id",
      name: "Schedule ID",
    },
    "-",
    {
      element: "typedDropdown",
      storeAs: "time",
      name: "Run",
      choices: {
        dontChange: { name: "Don't Change", field: true },
        timestamp: { name: "At Timestamp", field: true },
        seconds: { name: "In # Seconds", field: true },
        minutes: { name: "In # Minutes", field: true },
        hours: { name: "In # Hours", field: true },
        days: { name: "In # Days", field: true },
        weeks: { name: "In # Weeks", field: true },
        months: { name: "In # Months", field: true },
      }
    },
    "-",
    {
      element: "variable",
      name: "Associated Information",
      optional: true,
      storeAs: "associatedInfo",
      additionalOptions: {
        dontChange: { name: "Don't Change", field: true },
        text: { name: "Text", field: true }
      }
    },
  ],
  subtitle: (values, constants, thisAction) => {
    return `ID (${values.id})`
  },

  run(values, message, client, bridge) {
    let schedules = bridge.data.IO.schedules.get();
    let schedule = schedules[bridge.transf(values.id)];

    if (values.associatedInfo.type != 'dontChange') {
      if (values.associatedInfo.type == 'text') {
        schedule.associatedInfo = bridge.transf(values.associatedInfo.value);
      } else {
        schedule.associatedInfo = bridge.get(values.associatedInfo);
      }
    }

    let timeUnits = {
      seconds: 1000,
      minutes: 1000 * 60,
      hours: 1000 * 60 * 60,
      days: 1000 * 60 * 60 * 24,
      weeks: 1000 * 60 * 60 * 24 * 7,
      months: 1000 * 60 * 60 * 24 * 30,
    };
    
    if (values.time.type != 'dontChange') {
      if (timeUnits[values.time.type]) {
        schedule.time = Date.now() + (timeUnits[values.time.type] * bridge.transf(values.time.value));
      } else {
        schedule.time = bridge.transf(values.time.value);
      }
    }

    schedules[bridge.transf(values.id)] = schedule;
    bridge.data.IO.schedules.write(schedules)
  },
};
