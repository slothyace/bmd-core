module.exports = {
  name: "Nothing",
  nameSchemes: [],
  initialize(client, data, run) {}
}
